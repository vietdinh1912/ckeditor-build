const Users = [
    {
        "device_id": "prikshit",
        "name": "Prikshit",
        "username": "prikshit",
        "email": "prikshit@cly.com",
        "organization": "Google",
        "phone": "+919882201994",
        "gender": "M",
        "byear": "1994"
    },
    {
        "device_id": "alex",
        "name": "Alex",
        "username": "alex",
        "email": "alex@cly.com",
        "organization": "Amazom",
        "phone": "+919882202010",
        "gender": "M",
        "byear": "2010"
    },
    {
        "device_id": "hannah",
        "name": "Hannah",
        "username": "hannah",
        "email": "hannah@cly.com",
        "organization": "Facebook",
        "phone": "+919882202000",
        "gender": "F",
        "byear": "2000"
    },
    {
        "device_id": "jarvis",
        "name": "Jarvis",
        "username": "jarvis",
        "email": "jarvis@cly.com",
        "organization": "Tony Stark corp",
        "phone": "+919882202013",
        "gender": "F",
        "byear": "2013"
    },
];

export default Users;