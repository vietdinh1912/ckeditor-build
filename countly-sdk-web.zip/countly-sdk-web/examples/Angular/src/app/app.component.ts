import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['../../../style/style.css']
})
export class AppComponent {
  title = 'Angular';
}
