# Countly Implementation Examples

This folder is filled with examples of Countly implementations to help you to get an idea
how to integrate Countly into your own personal project too.

For all projects you should change 'YOUR_APP_KEY' value with your own application's app key, 'https://try.count.ly' value with your own server url. 

If you have not separated 'examples' folder from the 'COUNTLY-SDK-WEB' project folder nor made some changes to file names in the periphery, any path to countly.js or the plugins must be still correct. 

But if you did make some changes you should check if the paths, like '../lib/countly.js', are correct or not inside the example files.
